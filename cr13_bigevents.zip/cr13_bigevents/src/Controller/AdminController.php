<?php

namespace App\Controller;

use App\Entity\Events;
use App\Form\EventsType;
use App\Repository\EventsRepository;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;

// classes for FormController
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;



class AdminController extends AbstractController
{
    /**
     * @Route("/admin", name="admin")
     */
    public function showAction()
    {
        $events = $this->getDoctrine()->getRepository('App:Events')->findAll();
        return $this->render('admin/index.html.twig', array('events'=>$events));
    }
 
 
    /**
     * @Route("/create", name="create_page")
     */
    public function createAction(Request $request)
    {
        $events = new Events;
 
        $form = $this->createFormBuilder($events)
                     ->add('name',TextType::class, array('attr' => array('class'=> 'form-control', 'style' => 'margin-bottom:15px')))
                     ->add('type',TextType::class, array('attr' => array('class'=> 'form-control', 'style' => 'margin-bottom:15px')))
                     ->add('startDate',DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))
                     ->add('description',TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))
                     ->add('image',TextType::class, array('attr' => array('class'=> 'form-control', 'style' => 'margin-bottom:15px')))
                     ->add('capacity',TextType::class, array('attr' => array('class'=> 'form-control', 'style' => 'margin-bottom:15px')))
                     ->add('location',TextType::class, array('attr' => array('class'=> 'form-control', 'style' => 'margin-bottom:15px')))
                     ->add('street',TextType::class, array('attr' => array('class'=> 'form-control', 'style' => 'margin-bottom:15px')))
                     ->add('city',TextType::class, array('attr' => array('class'=> 'form-control', 'style' => 'margin-bottom:15px')))
                     ->add('zipcode',TextType::class, array('attr' => array('class'=> 'form-control', 'style' => 'margin-bottom:15px')))
                     ->add('telno',TextType::class, array('attr' => array('class'=> 'form-control', 'style' => 'margin-bottom:15px')))
                     ->add('email',TextType::class, array('attr' => array('class'=> 'form-control', 'style' => 'margin-bottom:15px')))
                     ->add('website',TextType::class, array('attr' => array('class'=> 'form-control', 'style' => 'margin-bottom:15px')))
                     ->add('save',SubmitType::class, array('label' => 'Add Event', 'attr' => array('class'=> 'btn-success', 'style' => 'margin-bottom:15px')))
 
                     ->getForm();
                     $form->handleRequest($request);
 
             if($form->isSubmitted() && $form->isValid()){
 
                 $name = $form['name']->getData();
                 $type = $form['type']->getData();
                 $startDate = $form['startDate']->getData();
                 $description = $form['description']->getData();
                 $image = $form['image']->getData();
                 $capacity = $form['capacity']->getData();
                 $location = $form['location']->getData();
                 $street = $form['street']->getData();
                 $city = $form['city']->getData();
                 $zipcode = $form['zipcode']->getData();
                 $telno = $form['telno']->getData();
                 $email = $form['email']->getData();
                 $website = $form['website']->getData();
                 
                 
                 $events->setName($name);
                 $events->setType($type);
                 $events->setStartDate($startDate);
                 $events->setDescription($description);
                 $events->setImage($image);
                 $events->setCapacity($capacity);
                 $events->setLocation($location);
                 $events->setStreet($street);
                 $events->setCity($city);
                 $events->setZipcode($zipcode);
                 $events->setTelno($telno);
                 $events->setEmail($email);
                 $events->setWebsite($website);
 
                 $em = $this->getDoctrine()->getManager();
                 $em->persist($events);
                 $em->flush();
 
                 $this->addFlash(
                         'notice',
                         'Event Added'
                         );
 
                         return $this->redirectToRoute('admin');
                     }
 
                     return $this->render('admin/create.html.twig', array('form' => $form->createView()));
     }
 
 
 
    /**
     * @Route("/edit/{id}", name="edit_page")
     */
    public function editAction($id, Request $request)
    {
        $events = $this->getDoctrine()->getRepository('App:Events')->find($id);
 
                 $events->setName($events->getName());
                 $events->setType($events->getType());
                 $events->setStartDate($events->getStartDate());
                 $events->setDescription($events->getDescription());
                 $events->setImage($events->getImage());
                 $events->setCapacity($events->getCapacity());
                 $events->setLocation($events->getLocation());
                 $events->setStreet($events->getStreet());
                 $events->setCity($events->getCity());
                 $events->setZipcode($events->getZipcode());
                 $events->setTelno($events->getTelno());
                 $events->setEmail($events->getEmail());
                 $events->setWebsite($events->getWebsite());
 
         $form = $this->createFormBuilder($events)
                    ->add('name',TextType::class, array('attr' => array('class'=> 'form-control', 'style' => 'margin-bottom:15px')))
                    ->add('type',TextType::class, array('attr' => array('class'=> 'form-control', 'style' => 'margin-bottom:15px')))
                    ->add('startDate',DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))
                    ->add('description',TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))
                    ->add('image',TextType::class, array('attr' => array('class'=> 'form-control', 'style' => 'margin-bottom:15px')))
                    ->add('capacity',TextType::class, array('attr' => array('class'=> 'form-control', 'style' => 'margin-bottom:15px')))
                    ->add('location',TextType::class, array('attr' => array('class'=> 'form-control', 'style' => 'margin-bottom:15px')))
                    ->add('street',TextType::class, array('attr' => array('class'=> 'form-control', 'style' => 'margin-bottom:15px')))
                    ->add('city',TextType::class, array('attr' => array('class'=> 'form-control', 'style' => 'margin-bottom:15px')))
                    ->add('zipcode',TextType::class, array('attr' => array('class'=> 'form-control', 'style' => 'margin-bottom:15px')))
                    ->add('telno',TextType::class, array('attr' => array('class'=> 'form-control', 'style' => 'margin-bottom:15px')))
                    ->add('email',TextType::class, array('attr' => array('class'=> 'form-control', 'style' => 'margin-bottom:15px')))
                    ->add('website',TextType::class, array('attr' => array('class'=> 'form-control', 'style' => 'margin-bottom:15px')))
                    ->add('save',SubmitType::class, array('label' => 'Save', 'attr' => array('class'=> 'btn-success', 'style' => 'margin-bottom:15px')))
                     
 
                     ->getForm();
                     $form->handleRequest($request);
 
             if($form->isSubmitted() && $form->isValid()){
 
                 $name = $form['name']->getData();
                 $type = $form['type']->getData();
                 $startDate = $form['startDate']->getData();
                 $description = $form['description']->getData();
                 $image = $form['image']->getData();
                 $capacity = $form['capacity']->getData();
                 $location = $form['location']->getData();
                 $street = $form['street']->getData();
                 $city = $form['city']->getData();
                 $zipcode = $form['zipcode']->getData();
                 $telno = $form['telno']->getData();
                 $email = $form['email']->getData();
                 $website = $form['website']->getData();
                 
 
                 $em = $this->getDoctrine()->getManager();
                 $events = $em->getRepository('App:events')->find($id);
 
                 $events->setName($name);
                 $events->setType($type);
                 $events->setStartDate($startDate);
                 $events->setDescription($description);
                 $events->setImage($image);
                 $events->setCapacity($capacity);
                 $events->setLocation($location);
                 $events->setStreet($street);
                 $events->setCity($city);
                 $events->setZipcode($zipcode);
                 $events->setTelno($telno);
                 $events->setEmail($email);
                 $events->setWebsite($website);
 
                 $em->flush();
 
                 $this->addFlash(
                         'notice',
                         'Entry modified'
                         );
 
                         return $this->redirectToRoute('admin');
                     }
 
 
 
        return $this->render('admin/edit.html.twig', array('events' => $events, 'form' => $form->createView()));
    }
 
 
 
    /**
     * @Route("/details/{id}", name="details_page")
     */
    public function detailsAction($id)
    {
        $events = $this->getDoctrine()->getRepository('App:Events')->find($id);
 
        return $this->render('admin/details.html.twig', array('events' => $events));
    }
 
 
     
     /**
     * @Route("/delete/{id}", name="todo_delete")
     */
     public function deleteAction($id){
 
     $em = $this->getDoctrine()->getManager();
     $events = $em->getRepository('App:Events')->find($id);
 
     $em->remove($events);
         $em->flush();
     $this->addFlash(
             'notice',
             'Event Removed'
             );
 
     return $this->redirectToRoute('admin');
 }
 
     
 }