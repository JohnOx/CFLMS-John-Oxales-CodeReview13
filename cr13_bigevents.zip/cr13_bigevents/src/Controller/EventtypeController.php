<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

class EventtypeController extends AbstractController
{
    /**
     * @Route("/eventtype", name="All_Types")
     */
    public function showAllTypes()
    {
        $events = $this->getDoctrine()->getRepository('App:Events')->findAll();
        return $this->render('eventtype/index.html.twig', array('events'=>$events));
    }

      /**
     * @Route("/musicals", name="Musicals" , methods={"GET"})
     */
    public function showMusicals()
    {
        $events = $this->getDoctrine()->getRepository('App:Events')->findBy(['type' => 'musical']);
        return $this->render('eventtype/index.html.twig', array('events'=>$events));
    }

       /**
     * @Route("/movies", name="Movies" , methods={"GET"})
     */
    public function showMovies()
    {
        $events = $this->getDoctrine()->getRepository('App:Events')->findBy(['type' => 'movie']);
        return $this->render('eventtype/index.html.twig', array('events'=>$events));
    }

     /**
     * @Route("/sports", name="Sports" , methods={"GET"})
     */
    public function showSports()
    {
        $events = $this->getDoctrine()->getRepository('App:Events')->findBy(['type' => 'sport']);
        return $this->render('eventtype/index.html.twig', array('events'=>$events));
    }


       /**
     * @Route("/theaters", name="Theaters" , methods={"GET"})
     */
    public function showTheaters()
    {
        $events = $this->getDoctrine()->getRepository('App:Events')->findBy(['type' => 'theater']);
        return $this->render('eventtype/index.html.twig', array('events'=>$events));
    }


       /**
     * @Route("/operas", name="Operas" , methods={"GET"})
     */
    public function showOperas()
    {
        $events = $this->getDoctrine()->getRepository('App:Events')->findBy(['type' => 'opera']);
        return $this->render('eventtype/index.html.twig', array('events'=>$events));
    }


      

    
}
